/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author test1
 */
public class addition 
{    
    public int[][] add(int[][] matA,int[][] matB , int rowA, int colA, int rowB, int colB )
    {
         int[][] res=new int[rowA][colA];
        if(rowA==rowB&&colA==colB)
        {
        System.out.println("Sum = ");
         for (int i = 0; i < rowA; i++)
        {
            for (int j = 0; j < colA; j++)
            {
                res[i][j] = matA[i][j] + matB[i][j];
                 
                System.out.print(res[i][j]+"\t");
            } System.out.println();          

        }
        } else System.out.println("No. of Rows or Column are not same.");
        
    return res;
    }
}
