/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Taha PC
 */
public class multiplication 
{
    
    public int[][] mul(int[][] matA,int[][] matB , int rowA, int colA, int rowB, int colB)
    { int[][] res=new int[rowA][colA];
        if(rowA==colB && rowB==colA)
        {
        
       // int[][] res=new int[rowA][colB];
        
        for (int i = 0; i < rowA; i++)
        {
            for (int j = 0; j < rowB; j++)
            {
                for (int k = 0; k < rowA; k++)
                {
                    res[i][j] = res[i][j] + matA[i][k] * matB[k][j];
                }
            }
        }  
        
        
        
        
        
        
        
        System.out.println("Multiplied Matrix: ");
        for (int i =0; i<rowA; i++)
        {
        for (int j =0; j<colB; j++)              
        {
            System.out.print(res[i][j] + "\t");
        } System.out.println();
        }
        } else System.out.println("Matrix can not be Multipiled with these Dimensions..");
    
    return res;
    }
}
