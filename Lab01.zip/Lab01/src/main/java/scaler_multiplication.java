/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Taha PC
 */
public class scaler_multiplication 
{
        //int[][] res=new int[rowA][colA];
    public int[][] s_mul (int[][] matA, int rowA, int colA, int x)
    {
        int[][] res=new int[rowA][colA];
        System.out.println("Scaler Multiplication = ");
        for (int i = 0; i < rowA; i++)
        {
            for (int j = 0; j < colA; j++)
            {
                res[i][j] = matA[i][j] * x;
                 
                System.out.print(res[i][j]+"\t");
            } System.out.println();          

        }
        return res;
    }
}

