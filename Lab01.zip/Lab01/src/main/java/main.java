
import java.util.Scanner;
import java.util.Random;
import java.util.StringTokenizer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author test1
 */
public class main 
{
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter No of rows for Matrix A:");
    int rowA = sc.nextInt();
    System.out.println("Enter No of columns for Matrix A:");
    int colA = sc.nextInt();
    
    System.out.println("Enter No of rows for Matrix B:");
    int rowB = sc.nextInt();
    System.out.println("Enter No of columns for Matrix B:");
    int colB = sc.nextInt();
    
    
    
    int[][] matA=new int[1000][1000];
    int[][] matB=new int[1000][1000];
    int[][] res=new int[1000][1000];
    
    
  //  System.out.println("Enter Data for 1st Matrix: ");
    
    for (int i =0; i<rowA; i++)
    {
        for (int j =0; j<colA; j++)
        {
            Random rand = new Random();
            matA[i][j] = rand.nextInt(10) + 1;
           
        }
    }
    
    
        for (int i =0; i<rowB; i++)
    {
        for (int j =0; j<colB; j++)
        {
            Random rand = new Random();
            matB[i][j] = rand.nextInt(10) + 1;
           
        }
    }
    
//        System.out.println("Enter Data for 2nd Matrix: ");
//    
//    for (int i =0; i<row; i++)
//    {
//        for (int j =0; j<col; j++)
//        {
//            matB[i][j]= sc.nextInt();
//        }
//    }
//    
        System.out.println("1st Matrix: ");
    
    for (int i =0; i<rowA; i++)
    {
        for (int j =0; j<colA; j++)
        {
            System.out.print(matA[i][j] + "\t");
        }System.out.println();
    }
    
        System.out.println("2nd Matrix: ");
        for (int i =0; i<rowB; i++)
        {
        for (int j =0; j<colB; j++)
        {
            System.out.print(matB[i][j] + "\t");
        } System.out.println();
        }
    
        
        //addition a1=new addition();
        //a1.add(matA, matB, rowA, colA,rowB, colB);
        
        //subtraction s1=new subtraction();
        //s1.(matA, matB, rowA, colA,rowB, colB);
       
       //multiplication m1=new multiplication();
       //m1.mul(matA, matB, rowA, colA,rowB, colB);
        
        //scaler_multiplication s1=new scaler_multiplication();
        //s1.s_mul(matA, rowA, colA, 3);
        
       // tranpose t1=new tranpose();
        //t1.tra(matA,rowA,colA);
        
        
        
        
          /*System.out.println("Sum = ");
         for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                res[i][j] = matA[i][j] + matB[i][j];
                 
                System.out.print(res[i][j]+"\t");
            } System.out.println();          

        
        }*/
          
          System.out.println("Enter Expression: ");
          String exp=sc.nextLine();
          
          StringTokenizer stk = new StringTokenizer(exp);
           String mat1 = stk.nextToken();
            String op = stk.nextToken();
           String mat2 = stk.nextToken();
           
           if(op.equals("+"))
           {
            addition a1=new addition();
            a1.add(matA, matB, rowA, colA,rowB, colB);   
           }
           else if(op.equals("-"))
           {
            subtraction s1=new subtraction();
          // s1.(matA, matB, rowA, colA,rowB, colB);
           }
           else  if(op.equals("*"))
           {
           multiplication m1=new multiplication();
            m1.mul(matA, matB, rowA, colA,rowB, colB);
           }
              if(op.equals("t"))
           {
             tranpose t1=new tranpose();
        t1.tra(matA,rowA,colA); 
           }
    

    }
}
